<?php
$token = 'ТОКЕН ОТ БОТА';
$chat_id = 'ЧАТ В ТГ';